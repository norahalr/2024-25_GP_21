#!/usr/bin/python3.12

import faiss
import openai
import sqlite3
import numpy as np

# Load OpenAI API key
OPENAI_API_KEY = "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"
openai.api_key = OPENAI_API_KEY

def embed_text(text):
    """Convert text to an OpenAI embedding vector (New API)"""
    client = openai.OpenAI(api_key=OPENAI_API_KEY)
    response = client.embeddings.create(
        model="text-embedding-ada-002",
        input=[text]  # Input must be a list
    )
    return np.array(response.data[0].embedding, dtype=np.float32)
# Connect to database
conn = sqlite3.connect("chatbot.db")
cursor = conn.cursor()

# Create chatbot_questions table
cursor.execute("""
CREATE TABLE IF NOT EXISTS chatbot_questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    answer TEXT NOT NULL
);
""")
cursor.executescript(open("chatbot.sql").read())
conn.commit()

# 🔁 SELECT from the table before closing the connection
cursor.execute("SELECT id, question, answer FROM chatbot_questions")
faq_data = cursor.fetchall()

# ✅ Close connection after fetching data
conn.close()

print("Table created successfully.")

# Convert questions into embeddings
faq_ids, faq_questions, faq_answers, faq_vectors = [], [], [], []
for row in faq_data:
    faq_ids.append(row[0])
    faq_questions.append(row[1])
    faq_answers.append(row[2])
    faq_vectors.append(embed_text(row[1]))

# Build FAISS index
index = faiss.IndexFlatL2(len(faq_vectors[0]))  # L2 distance for similarity
index.add(np.array(faq_vectors))

# Save index to disk
faiss.write_index(index, "faq_index.faiss")
np.save("faq_answers.npy", faq_answers)

print("✅ FAQ database indexed successfully!")
