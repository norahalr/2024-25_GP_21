#!/usr/bin/python3.12

import openai
import faiss
import numpy as np

# Create OpenAI client
client = openai.OpenAI(api_key="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")  # your actual API key here

# Load FAISS index and answers
index = faiss.read_index("/home/app8800/AI/faq_index.faiss")
faq_answers = np.load("/home/app8800/AI/faq_answers.npy", allow_pickle=True)

# Embed user message
def embed_text(text):
    response = client.embeddings.create(
        model="text-embedding-ada-002",
        input=[text]
    )
    return np.array(response.data[0].embedding, dtype=np.float32)

# Semantic search + GPT
def get_best_answer(user_message):
    embedded_query = embed_text(user_message)
    D, I = index.search(np.array([embedded_query]), k=1)

    best_match = faq_answers[I[0][0]]

    # Use GPT to generate a refined, helpful response
    response = client.chat.completions.create(
        model="gpt-4",  # or "gpt-4"
        messages=[
            {"role": "system", "content": "You are InnoBot, a helpful assistant for graduation project students using the Innovation Engine website. Answer clearly and supportively."},
            {"role": "user", "content": f"The student asked: '{user_message}'. Here's a related FAQ answer: '{best_match}'. Provide a helpful response."}
        ]
    )

    return response.choices[0].message.content.strip()
