CREATE TABLE IF NOT EXISTS chatbot_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    answer TEXT NOT NULL
);

INSERT INTO chatbot_questions (question, category, answer) VALUES
-- General Questions
("How does this website work?", "General", "The Innovation Engine helps students find supervisors and submit graduation project ideas efficiently."),
("What is the purpose of Innovation Engine?", "General", "It centralizes graduation project management, ensuring smooth collaboration between students and supervisors."),
("How do I create an account?", "General", "Click on the 'Sign Up' button, enter your group if you are a leader details , and verify your email."),
("How do I reset my password?", "General", "Go to the login page and click 'Forgot Password' to reset your password via email."),

-- Project Submission
("How do I submit my project idea?", "Submission", "find a sutible supervisore, fill out your idea details, and click submit."),
("Can I submit more than one idea?", "Submission", "yes, you can submit 3 ongoin idea per team."),
("What happens after I submit my idea?", "Submission", "Your idea will be reviewed, and a supervisor may be assigned if it meets the criteria."),
("How do I check if my project is already have been done before?", "Submission", "The system automatically checks for duplicate ideas before submission."),

-- Supervisor Matching
("How does the supervisor matching system work?", "Supervisor", "Supervisors are suggested based on your project topic and intrest and their availability."),
("How do I find available supervisors?", "Supervisor", "Go to the supervisors section to see who is available."),
-- ("Can I change my supervisor later?", "Supervisor", "Yes, but you need approval from the academic department."),
("What if no supervisor is available for my project?", "Supervisor", "The system will notify the admin to assign one manually."),

-- Editing or Deleting a Request
("How do I edit my project request?", "Editing", "Go to 'My Requests' and click edit to modify your idea only if it a students project idea."),
("Can I delete my submitted project idea?", "Editing", "Yes, but only before a supervisor is assigned."),
("Why can’t I delete my project?", "Editing", "If a supervisor is assigned, you must contact the admin to request deletion."),
("What happens if my project request is rejected?", "Editing", "You will receive feedback, and you can resubmit after making the necessary changes."),

-- Collaboration & Assistance
-- ("Can I collaborate with students from other colleges?", "Collaboration", "Yes! You can request assistance from students in different fields."),
("How does interdisciplinary collaboration work?", "Collaboration", "Colleges and companies can share expertise and resources to improve project quality."),
-- ("How can companies or ministries assist my project?", "Collaboration", "They can offer funding, mentorship, and real-world application support."),

-- Chatbot-Specific
("What can you do?", "Chatbot", "I can help you understand the website, find supervisors, and guide you through project submission."),
("Can you explain my project submission status?", "Chatbot", "I can check your project status and inform you of any required actions."),
("Can you tell me which supervisors are available?", "Chatbot", "Yes! I can list available supervisors based on their expertise."),
("How accurate is your information?", "Chatbot", "I provide real-time data based on the website's latest updates.");

