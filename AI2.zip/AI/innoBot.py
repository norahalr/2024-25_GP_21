from flask import Flask, request, jsonify
from flask_cors import CORS, cross_origin
from chatbot_Responses import get_best_answer  # Your logic for answering
app = Flask(__name__)
CORS(app)

@app.route("/chatbot", methods=['GET', 'POST'])
@cross_origin(origin='*')
def chatbot():
    user_message = request.json.get("message", "")
    reply = get_best_answer(user_message)
    return jsonify({"reply": reply})

@app.after_request
def after_request(response):
    header = response.headers
    header['Access-Control-Allow-Origin'] = '*'
    header['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    header['Access-Control-Allow-Methods'] = 'OPTIONS, HEAD, GET, POST, DELETE, PUT'
    return response

if __name__ == "__main__":
    context = ('cert.pem', 'key.pem')
    app.run(host='0.0.0.0', port=5008, ssl_context=context)