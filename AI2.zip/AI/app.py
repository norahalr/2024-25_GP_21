#!/usr/bin/python3.12

from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import mysql.connector
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer, util
from chromadb import Client
from chromadb.utils import embedding_functions
import openai
import re
from chromadb import PersistentClient
from openai import OpenAI

# === Flask setup ===
app = Flask(__name__)
CORS(app)
openai.api_key ="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"

# === Models & Embeddings ===
model = SentenceTransformer('all-MiniLM-L6-v2')  # used for supervisor recommendation
model2 = SentenceTransformer('all-mpnet-base-v2')  # used for semantic similarity

# === Load past projects for duplicate detection ===
past_projects_df = pd.read_csv('/home/app8800/AI/past_projects.csv')
past_projects = past_projects_df['description'].tolist()
past_project_names = past_projects_df['name'].tolist()

@app.route("/")
def home():
    return "✅ InnoBot and recommender are running!"

# === Chatbot (OpenAI API + ChromaDB) ===
@app.route("/chatbot", methods=["POST", "OPTIONS"])
def chatbot():
    if request.method == "OPTIONS":
        response = jsonify({})
        response.headers.add("Access-Control-Allow-Origin", "https://www.innovationenginee.com")
        response.headers.add("Access-Control-Allow-Headers", "Content-Type")
        response.headers.add("Access-Control-Allow-Methods", "POST, OPTIONS")
        return response, 204

    data = request.get_json()
    question = data.get("message")
    if not question:
        return jsonify({"reply": "No question provided."}), 400

    chroma_client = PersistentClient(path="/home/app8800/AI/chroma")
    openai_embedder = embedding_functions.OpenAIEmbeddingFunction(
        api_key=openai.api_key,
        model_name="text-embedding-3-small"
    )
    collection = chroma_client.get_or_create_collection("gp_docs", embedding_function=openai_embedder)
    results = collection.query(query_texts=[question], n_results=3)
    if not results['documents'] or not results['documents'][0]:
        return jsonify({"reply": "Sorry, I couldn't find relevant information in the documents."})

    context = "\n---\n".join(results['documents'][0])
    prompt = f"""
You are InnoBot, an assistant for graduation project students.
Answer the question based only on the documents below.

{context}

Student question: {question}
Answer:
"""

    openai_client = OpenAI(api_key=openai.api_key)
    response = openai_client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    reply = response.choices[0].message.content.strip()
    response = jsonify({ "reply": reply })
    response.headers["Access-Control-Allow-Origin"] = "https://www.innovationenginee.com"
    return response

@app.route("/debug_docs", methods=["GET"])
def debug_docs():
    try:
        openai_embedder = embedding_functions.OpenAIEmbeddingFunction(
            api_key=openai.api_key,
            model_name="text-embedding-3-small"
        )
        client = PersistentClient(path="/home/app8800/AI/chroma")
        collection = client.get_or_create_collection("gp_docs", embedding_function=openai_embedder)
        all_docs = collection.peek()

        doc_count = len(all_docs.get("documents", []))
        return jsonify({
            "doc_count": doc_count,
            "example": all_docs.get("documents", [])
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# === Database connection ===
def get_db_connection():
    return mysql.connector.connect(
        host='srv2000.hstgr.io',
        user='u253034616_root',
        password='INNOVATION@engine2025',
        database='u253034616_innovation'
    )

def get_supervisors():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT email, name, interest, availability FROM supervisors")
    data = cursor.fetchall()
    df = pd.DataFrame(data, columns=["email", "name", "interest", "availability"])
    cursor.close()
    conn.close()
    return df

def get_student_interests(student_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT interest FROM students WHERE email=%s", (student_id,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result[0] if result else ""

# === Text Normalization & Synonym Expansion ===
def normalize_text(text):
    return text.lower()

def expand_text(text):
    synonyms = {
        "Machine Learning": ["ML", "machine learning"],
        "Deep Learning": ["DL", "deep learning"],
        "Artificial Intelligence": ["AI", "artificial intelligence"],
        "Natural Language Processing": ["NLP", "natural language processing"],
        "Cloud Computing": ["Cloud", "cloud", "AWS", "Azure", "GCP"],
        "Face Recognition": ["Face ID", "face recognition"],
        "Internet of Things": ["IoT", "internet of things"],
        "Smart Devices": ["smart devices"],
        "Networking Technologies": ["Networking", "Computer Networks"],
        "Data Monitoring": ["Monitoring"],
        "Data Analysis": ["DA", "data analysis"],
        "Big Data": ["BD", "big data"],
        "Recommendation System": ["Recommender", "recommendation system"]
    }
    text = text.lower()
    for key, values in synonyms.items():
        for v in values:
            pattern = r'\b' + re.escape(v.lower()) + r'\b'
            text = re.sub(pattern, key.lower(), text)
    return ', '.join(p.strip() for p in text.split(',') if p.strip())

# === Supervisor Recommender ===
class SupervisorRecommender:
    def __init__(self, df):
        self.supervisors = df.dropna(subset=['interest'])

    def recommend_supervisors(self, student_interests, threshold=0.5):
        student_topics = [expand_text(topic.strip()) for topic in student_interests.split(',')]
        student_vectors = [model.encode(topic) for topic in student_topics]

        similarities = []
        for _, row in self.supervisors.iterrows():
            supervisor_topics = [expand_text(topic.strip()) for topic in row['interest'].split(',')]
            supervisor_vectors = [model.encode(topic) for topic in supervisor_topics]

            max_similarity = 0
            for s_vec in student_vectors:
                for t_vec in supervisor_vectors:
                    sim = cosine_similarity([s_vec], [t_vec])[0][0]
                    if sim > max_similarity:
                        max_similarity = sim

            similarities.append(max_similarity)

        self.supervisors['similarity'] = similarities
        top_matches = self.supervisors[self.supervisors['similarity'] > threshold].sort_values(by='similarity', ascending=False)
        return top_matches[["email", "name", "interest", "availability", "similarity"]].to_dict(orient='records')

@app.route("/recommend", methods=["GET"])
def recommend():
    student_id = request.args.get("student_id")
    threshold = float(request.args.get("threshold", 0.5))

    if not student_id:
        return jsonify({"error": "Missing student_id"}), 400

    student_interests = get_student_interests(student_id)
    if not student_interests:
        return jsonify({"error": "No interests found for student"}), 404

    recommender = SupervisorRecommender(get_supervisors())
    recs = recommender.recommend_supervisors(student_interests, threshold)

    if not recs:
        return jsonify({"message": "No matching supervisors found. Try lowering the threshold."})

    return jsonify({"recommended_supervisors": recs})

# === Similar Supervisor Suggestions ===
def calculate_similarity(a, b):
    a_set = set(re.split(r'\s*,\s*', a.strip()))
    b_set = set(re.split(r'\s*,\s*', b.strip()))
    return len(a_set & b_set), a_set & b_set

@app.route("/supervisor/<email>", methods=["GET"])
def get_similar_supervisors(email):
    df = get_supervisors()
    target = df[df["email"] == email]
    if target.empty:
        return jsonify({"error": "Supervisor not found"}), 404
    target_interests = expand_text(target.iloc[0]["interest"])
    results = []
    for _, row in df.iterrows():
        if row["email"] == email:
            continue
        count, common = calculate_similarity(target_interests, expand_text(row["interest"]))
        if count > 0:
            results.append({
                "email": row["email"],
                "name": row["name"],
                "interest": row["interest"],
                "availability": row["availability"],
                "common_interests": list(common),
                "similarity_count": count
            })
    return jsonify({"similar_supervisors": sorted(results, key=lambda x: x["similarity_count"], reverse=True)[:4]})

# === Duplicate Idea Detection ===
STOP_WORDS = {"it's", "ksu", "the", "this", "that", "application", "platform", "is", "an", "designed", "to", "by", " ", ".", ",", "mobile", "developed", "ai", "artificial", "intelligence", "virtual", "reality"}

def preprocess(doc):
    return {word.lower() for word in doc.split() if word.lower() not in STOP_WORDS}

def dice_coefficient(a, b):
    intersection = len(a & b)
    return 2 * intersection / (len(a) + len(b)) if (len(a) + len(b)) > 0 else 0


# === Semantic Search: Duplicate Idea Detection (Cosine + Dice) ===
@app.route("/check_duplicate", methods=["POST"])
def check_duplicate():
    data = request.get_json()
    new_idea = data.get("idea", "")
    if not new_idea:
        return jsonify({"error": "No idea provided"}), 400

    # Encode new project idea
    new_project_embedding = model2.encode(new_idea, convert_to_tensor=True)

    # Compute semantic similarity using cosine similarity
    past_embeddings = model2.encode(past_projects, convert_to_tensor=True)
    semantic_similarities = util.cos_sim(new_project_embedding, past_embeddings)[0].tolist()

    semantic_scores = []
    for name, sim in zip(past_project_names, semantic_similarities):
        sim = round(float(sim), 4)
        sim = min(1.0, sim)
        semantic_scores.append((name, sim))

    semantic_scores.sort(key=lambda x: x[1], reverse=True)
    best_match = semantic_scores[0]

    # Dice coefficient
    def preprocess(doc):
        return {word.lower() for word in doc.split() if word.lower() not in STOP_WORDS}

    preprocessed_query = preprocess(new_idea)
    preprocessed_descriptions = [preprocess(doc) for doc in past_projects]
    dice_similarities = [
        dice_coefficient(preprocessed_query, description) for description in preprocessed_descriptions
    ]
    best_dice_match = max(zip(past_project_names, dice_similarities), key=lambda x: x[1])

    return jsonify({
        "semantic_similarity": {
            "project_name": best_match[0],
            "similarity": best_match[1]
        },
        "dice_coefficient": {
            "project_name": best_dice_match[0],
            "similarity": best_dice_match[1]
        }
    })
