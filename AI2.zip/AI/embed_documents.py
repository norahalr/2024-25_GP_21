import os
import openai
import pdfplumber
from chromadb import PersistentClient
from chromadb.utils import embedding_functions

# CONFIGURE
openai.api_key = "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"
docs_folder = "docs"  # Folder containing GP PDFs

# Init Chroma with OpenAI embedder
openai_embedder = embedding_functions.OpenAIEmbeddingFunction(
    api_key=openai.api_key,
    model_name="text-embedding-3-small"
)

client = PersistentClient(path="/home/app8800/AI/chroma")

# 💥 This line is NEW: delete old incompatible collection if it exists
try:
    client.delete_collection("gp_docs")
except:
    pass  # Ignore if it doesn't exist

# ✅ Now create it cleanly with OpenAI embedder
collection = client.get_or_create_collection("gp_docs", embedding_function=openai_embedder)

# Read and embed
def load_and_embed_pdfs():
    for file_name in os.listdir(docs_folder):
        if file_name.endswith(".pdf"):
            with pdfplumber.open(os.path.join(docs_folder, file_name)) as pdf:
                full_text = "\n".join(
                    [page.extract_text() for page in pdf.pages if page.extract_text()]
                )
                chunks = [full_text[i:i+500] for i in range(0, len(full_text), 500)]
                for i, chunk in enumerate(chunks):
                    collection.add(
                        documents=[chunk],
                        ids=[f"{file_name}_{i}"],
                        metadatas=[{"source": file_name}]
                    )
    print("✅ All documents embedded and stored.")

if __name__ == "__main__":
    load_and_embed_pdfs()
